module.exports = {
    ADD_ROOT_NODE: 'add-root-node'
};